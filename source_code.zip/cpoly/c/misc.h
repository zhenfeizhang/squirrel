#ifndef MISC_H
#define MISC_H

void hexDump (const char *desc, const void *addr, const int len);

#endif