#ifndef PARAMS_H
#define PARAMS_H

#define SEEDBYTES 32
#define N 512
#define HVC_Q 12289

#endif
