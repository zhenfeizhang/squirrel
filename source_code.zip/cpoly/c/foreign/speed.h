#ifndef SPEED_H
#define SPEED_H

#define MSECS(t) ((double)(t)/(2600000))

void print_results(const char *s, unsigned long long *t, size_t tlen);

#endif
